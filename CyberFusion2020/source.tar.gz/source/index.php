<html>
<h1>Welcome to Cerealize! We're an up-and-coming cereal archival project.</h1>
<style>
body {
  background-color: orange;
}
</style>
<body>
<p>We hope to create an archive of every cereal ever created. We're like Wikipedia, but for cereal!</p>
<p>We're still hard at work building our archive. If you've got a cool cereal to submit to our cereal archive, please do so <a href="cerealize.php">here!</a></p>

<img src="Froot-Loops-Cereal-Bowl.jpg" width="500" height="500">
<img src="cereal-1262202_960_720.jpg" width="500" height="500">

</body>
</html>