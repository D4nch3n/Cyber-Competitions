<?php
	// all the secret proprietary cereals we signed NDAs to try are stored in a file
	// at /var/www/secret_archive.txt -- be sure to keep those hidden when we open-source our project!
	class secret_cereal_archive{
		public function __tostring(){
			return file_get_contents($this->filename);
		}
	}
?>