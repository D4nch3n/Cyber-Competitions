<html>
<h1>Archive submission</h1>
<style>
body {
  background-color: orange;
}
</style>

<h3>The Archive</h3>
<p>Hi! We want to build an archive of every known cereal, complete with name, flavor, and brand! It's too much work
for us to do on our own, so we need your help to grow the archive!</p>
<p>Please see below for submission guidelines.</p>

<h3>Submission guidelines</h3>
<p>Since we're still in development, we don't have a fancy frontend for submitting a new cereal for the archive. Instead, just give us
a POST request with a "cereal" parameter. Just for fun, why don't you serialize it? We've open-sourced the project,
so you can see what format we're expecting by checking out the code.</p>
<p>Thanks for your interest in contributing to the cereal archive!</p>

<img src="24261603568_ab2e4e58dc_b.jpg" width="500" height="500">
<img src="cereal.jpeg" width="500" height="500">
<br>

<?php
include 'archive_reader.php';

	class cereal{
		public $cereal_name;
		public $cereal_flavor;
		public $cereal_brand;

		public function submission_result(){
			echo "Thanks for submitting a new cereal for our archive!";
		}
		public function display_submission(){
			echo "You told us about" . $this->cereal_name . "; we'll see if it's in our archive! If not, we'll add it.";
		}
	}

	$cereal_submission = unserialize($_POST['cereal']);
	if ($cereal_submission){
		$cereal_submission->submission_result();
		if($cereal_submission->cereal_name && $cereal_submission->cereal_flavor && $cereal_submission->cereal_brand){
			$cereal_submission->display_submission();
		}
	}
	else{
		echo "Sorry, something's wrong with your cereal submission. Please try again.";
	}
?>

</html>